const mongoose = require('mongoose');

const TripSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  length: Number,
  start: String,
  resort: String,
  perPerson: Number,
  image: String,
  description: String
}, { timestamps: true });

module.exports = mongoose.model('Trip', TripSchema);
