const router = require('express').Router();
const { authRequired } = require('../middleware/auth');
const ctrl = require('../controllers/auth');

// Simple 'user-class' endpoint: who am I?
router.get('/me', authRequired, ctrl.me);

module.exports = router;
