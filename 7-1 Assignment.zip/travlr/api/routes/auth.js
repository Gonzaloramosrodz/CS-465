const router = require('express').Router();
const ctrl = require('../controllers/auth');
const { authRequired } = require('../middleware/auth');

router.post('/register', ctrl.register); // for testing/creating users (can be disabled in prod)
router.post('/login', ctrl.login);
router.get('/me', authRequired, ctrl.me);

module.exports = router;
