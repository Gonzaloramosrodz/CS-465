# Travlr (Module 7)

JWT-secured admin SPA and API.

## Quick start

1. Copy `.env.example` to `.env` and adjust if needed.
2. Install deps: `npm install`
3. Seed local DB (optional): `npm run seed`
4. Run: `npm run dev` (or `npm start`)

Default credentials: **admin@example.com / Admin123!**

- Admin SPA: `http://localhost:3000/admin`
- API: `http://localhost:3000/api`

## Testing with Postman
Import `postman/Travlr_Module7.postman_collection.json` and run:
- `POST /api/auth/login` to obtain a token.
- Call `POST/PUT/DELETE /api/trips` with `Authorization: Bearer <token>` and observe 401/403 without it.

## How your professor can run it

1. Copy `.env.example` to `.env` and keep defaults or set your own `MONGO_URI` and `JWT_SECRET`.

2. Install dependencies: `npm install`

3. Seed the database (creates the admin user): `npm run seed`

4. Start the server: `npm start` (or `npm run dev`) and visit `http://localhost:3000/admin`.

5. Use the credentials above to log in. CRUD buttons enable after login. 

6. Optional: import `postman/Travlr_Module7.postman_collection.json` to verify protected endpoints require a Bearer token.
