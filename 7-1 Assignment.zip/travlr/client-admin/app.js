const API = '/api';
const state = {
  token: localStorage.getItem('token') || null,
  user: null
};

function show(el){ el.classList.remove('hidden'); }
function hide(el){ el.classList.add('hidden'); }

async function login(email, password) {
  const res = await fetch(`${API}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  if (!res.ok) throw new Error('Login failed');
  const data = await res.json();
  state.token = data.token;
  localStorage.setItem('token', state.token);
  return data;
}

function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('token');
  location.reload();
}

async function fetchMe() {
  try {
    const res = await fetch(`${API}/auth/me`, { headers: { Authorization: `Bearer ${state.token}` }});
    if (!res.ok) return null;
    const me = await res.json();
    state.user = me;
    return me;
  } catch { return null; }
}

async function fetchTrips() {
  const res = await fetch(`${API}/trips`);
  return res.json();
}

async function createTrip(payload) {
  const res = await fetch(`${API}/trips`, {
    method:'POST',
    headers:{ 'Content-Type':'application/json', Authorization: `Bearer ${state.token}` },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('Create failed');
  return res.json();
}

async function updateTrip(id, payload) {
  const res = await fetch(`${API}/trips/${id}`, {
    method:'PUT',
    headers:{ 'Content-Type':'application/json', Authorization: `Bearer ${state.token}` },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('Update failed');
  return res.json();
}

async function deleteTrip(id) {
  const res = await fetch(`${API}/trips/${id}`, {
    method:'DELETE',
    headers:{ Authorization: `Bearer ${state.token}` }
  });
  if (!res.ok) throw new Error('Delete failed');
  return res.json();
}

function renderTrips(rows) {
  const tbody = document.querySelector('#trips-table tbody');
  tbody.innerHTML = '';
  rows.forEach(trip => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${trip.code}</td>
      <td>${trip.name}</td>
      <td>${trip.length ?? ''}</td>
      <td>${trip.start ?? ''}</td>
      <td>${trip.perPerson ?? ''}</td>
      <td class="actions">
        <button data-edit="${trip._id}">Edit</button>
        <button data-del="${trip._id}">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function readForm() {
  return {
    code: document.getElementById('code').value.trim(),
    name: document.getElementById('name').value.trim(),
    length: parseInt(document.getElementById('length').value || '0', 10) || undefined,
    start: document.getElementById('start').value.trim() || undefined,
    resort: document.getElementById('resort').value.trim() || undefined,
    perPerson: parseFloat(document.getElementById('perPerson').value || '0') || undefined,
    image: document.getElementById('image').value.trim() || undefined,
    description: document.getElementById('description').value.trim() || undefined,
  };
}

function writeForm(trip) {
  document.getElementById('trip-id').value = trip?._id || '';
  document.getElementById('code').value = trip?.code || '';
  document.getElementById('name').value = trip?.name || '';
  document.getElementById('length').value = trip?.length || '';
  document.getElementById('start').value = trip?.start || '';
  document.getElementById('resort').value = trip?.resort || '';
  document.getElementById('perPerson').value = trip?.perPerson || '';
  document.getElementById('image').value = trip?.image || '';
  document.getElementById('description').value = trip?.description || '';
}

async function refresh() {
  const trips = await fetchTrips();
  renderTrips(trips);
}

async function init() {
  const loginSection = document.getElementById('login-section');
  const authedSection = document.getElementById('authed-section');
  const loginForm = document.getElementById('login-form');
  const loginError = document.getElementById('login-error');
  const newBtn = document.getElementById('new-btn');
  const tripForm = document.getElementById('trip-form');
  const cancelEdit = document.getElementById('cancel-edit');

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.textContent = '';
    try {
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      await login(email, password);
      hide(loginSection);
      show(authedSection);
      await refresh();
    } catch (err) {
      loginError.textContent = 'Invalid login.';
      loginError.classList.remove('hidden');
    }
  });

  newBtn.addEventListener('click', () => {
    writeForm(null);
    show(tripForm);
  });

  cancelEdit.addEventListener('click', () => {
    hide(tripForm);
  });

  tripForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('trip-id').value;
    const payload = readForm();
    if (id) await updateTrip(id, payload);
    else await createTrip(payload);
    hide(tripForm);
    await refresh();
  });

  document.querySelector('#trips-table tbody').addEventListener('click', async (e) => {
    const editId = e.target.getAttribute('data-edit');
    const delId = e.target.getAttribute('data-del');
    if (editId) {
      const res = await fetch(`${API}/trips/${editId}`);
      const trip = await res.json();
      writeForm(trip);
      show(tripForm);
    } else if (delId) {
      await deleteTrip(delId);
      await refresh();
    }
  });

  document.getElementById('logout-btn').addEventListener('click', logout);

  // If token exists, try to resume session
  if (state.token) {
    const me = await fetchMe();
    if (me) {
      hide(loginSection);
      show(authedSection);
      await refresh();
    } else {
      logout();
    }
  }
}

document.addEventListener('DOMContentLoaded', init);
