const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const connectDB = require('../config/db');

const User = require('../api/models/user');
const Trip = require('../api/models/trip');

dotenv.config();

(async () => {
  try {
    await connectDB();
    const tripsData = JSON.parse(fs.readFileSync(path.join(__dirname, 'trips.json'), 'utf8'));
    const usersData = JSON.parse(fs.readFileSync(path.join(__dirname, 'users.json'), 'utf8'));

    await Promise.all([User.deleteMany({}), Trip.deleteMany({})]);

    const hashedUsers = await Promise.all(usersData.map(async (u) => ({
      email: u.email,
      passwordHash: await bcrypt.hash(u.password, 10),
      role: u.role || 'admin'
    })));

    const users = await User.insertMany(hashedUsers);
    const trips = await Trip.insertMany(tripsData);

    console.log(`Seeded ${users.length} user(s) and ${trips.length} trip(s).`);
    await mongoose.connection.close();
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();
