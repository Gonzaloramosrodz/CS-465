const router = require('express').Router();
const Trip = require('../api/models/trip');
const Booking = require('../api/models/booking');
const { register } = require('../api/controllers/auth');

// Home -> list trips with optional filters
router.get(['/', '/trips'], async (req, res) => {
  try {
    const { resort, maxPrice } = req.query;
    const q = {};
    if (resort) q.resort = resort;
    if (maxPrice) q.perPerson = { $lte: Number(maxPrice) };
    const trips = await Trip.find(q).sort({ createdAt: -1 });
    res.render('home', { layout: 'main', trips, filters: { resort, maxPrice } });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Trip detail
router.get('/trips/:id', async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.id);
    if (!trip) return res.status(404).send('Trip not found');
    res.render('trip', { layout: 'main', trip });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Booking submit (server-rendered)
router.post('/bookings', async (req, res) => {
  try {
    const { tripId, userEmail, travelers, startDate, notes } = req.body;
    if (!tripId || !userEmail) return res.status(400).send('tripId and userEmail required');
    const booking = await Booking.create({
      trip: tripId, userEmail, travelers: travelers || 1, startDate, notes
    });
    res.render('confirmation', { layout: 'main', bookingSuccess: true });
  } catch (err) {
    res.status(400).send(err.message);
  }
});

// Signup (customer)
router.get('/signup', (req, res) => {
  res.render('signup', { layout: 'main' });
});

router.post('/signup', async (req, res) => {
  try {
    const { email, password } = req.body;
    req.body.role = 'user';
    // reuse auth.register logic internally by calling API controller
    // but here call directly using the function to avoid HTTP
    // emulate req/res: instead, just create the user here for simplicity
    const auth = require('../api/controllers/auth');
    const fakeRes = {
      status(code){ this.code = code; return this; },
      json(obj){ this.obj = obj; }
    };
    await auth.register({ body: { email, password, role: 'user' } }, fakeRes);
    res.render('signup', { layout: 'main', success: true });
  } catch (err) {
    res.render('signup', { layout: 'main', error: err.message });
  }
});

module.exports = router;
