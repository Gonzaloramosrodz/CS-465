# Travlr – CS 465 Final Project

This repository contains the **final iteration** of the Travlr full stack application:

- **Customer-facing website** built with **Express + Handlebars (HBS)** following MVC
- **REST API** backed by **MongoDB (Mongoose models)**
- **Angular Admin SPA** for secure content management (login + trips CRUD)
- **Security** via JWT, with protected admin endpoints
- **Seed data** and **Postman** collection for quick testing

## 1) Run the Backend (Express + HBS + API)

```bash
cp .env.example .env
npm install
npm run seed
npm start
```

- Website: `http://localhost:3000/`
- API: `http://localhost:3000/api`
- Admin (built SPA files if you copy from admin build): `http://localhost:3000/admin`

Default users (after seeding):
- Admin: **admin@example.com / Admin123!**
- User: **user@example.com / User123!**

## 2) Run the Angular Admin SPA (dev)

```bash
cd admin-spa
npm install
npm start
```
- Angular dev server: `http://localhost:4200`
- The SPA assumes the backend API is at `http://localhost:3000/api`

## Customer Website (Express + HBS)

- Pages:
  - **/** or **/trips** – list & filter trips by `resort` and `maxPrice`
  - **/trips/:id** – trip detail + booking form
  - **/signup** – create a customer account (role=user)

## REST API (highlights)

- `GET /api/trips` (public, supports `?resort=&maxPrice=`)
- `GET /api/trips/:id` (public)
- `POST /api/trips` (admin)
- `PUT /api/trips/:id` (admin)
- `DELETE /api/trips/:id` (admin)
- `POST /api/bookings` (public create)
- `GET /api/bookings` (admin list)
- `POST /api/auth/login`, `POST /api/auth/register`, `GET /api/auth/me`

## Postman

Import `postman/Travlr_Final_Project.postman_collection.json` and test:
- Login → set `token` variable → call admin endpoints
- Positive/negative: verify 401/403 without token vs success with token

## Repo Structure

```
travlr/
  api/                # REST API (controllers, models, routes)
  website/            # Express MVC routes for customer-facing site
  views/              # Handlebars layouts, partials, pages
  public/             # Static assets (CSS, images)
  admin-spa/          # Angular SPA (login + trips CRUD)
  postman/            # Postman collection
  seed/               # Seed scripts + sample JSON
  config/             # DB config
  server.js
  .env.example
  package.json
  README.md
```

## Notes
- For production, you can build the Angular SPA (`npm run build`) and copy the output to `travlr/admin-spa-dist` to serve at `/admin` from Express.
- In dev, run both servers separately (`npm start` here and `npm start` in `admin-spa`).
