const router = require('express').Router();
const ctrl = require('../controllers/bookings');
const { authRequired, adminOnly } = require('../middleware/auth');

router.get('/', authRequired, adminOnly, ctrl.list); // admin review
router.post('/', ctrl.create); // public booking create

module.exports = router;
