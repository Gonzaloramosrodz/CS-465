const router = require('express').Router();
const ctrl = require('../controllers/trips');
const { authRequired, adminOnly } = require('../middleware/auth');

// Public
router.get('/', ctrl.list);
router.get('/:id', ctrl.get);

// Admin
router.post('/', authRequired, adminOnly, ctrl.create);
router.put('/:id', authRequired, adminOnly, ctrl.update);
router.delete('/:id', authRequired, adminOnly, ctrl.remove);

module.exports = router;
