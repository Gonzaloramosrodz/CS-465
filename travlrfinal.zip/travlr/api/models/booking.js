const mongoose = require('mongoose');
const BookingSchema = new mongoose.Schema({
  trip: { type: mongoose.Schema.Types.ObjectId, ref: 'Trip', required: true },
  userEmail: { type: String, required: true },
  travelers: { type: Number, default: 1 },
  startDate: { type: String },
  notes: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Booking', BookingSchema);
