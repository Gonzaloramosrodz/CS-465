const Booking = require('../models/booking');
const Trip = require('../models/trip');

exports.create = async (req, res) => {
  try {
    const { tripId, userEmail, travelers, startDate, notes } = req.body;
    if (!tripId || !userEmail) return res.status(400).json({ message: 'tripId and userEmail are required' });
    const exists = await Trip.findById(tripId);
    if (!exists) return res.status(404).json({ message: 'Trip not found' });
    const booking = await Booking.create({
      trip: tripId, userEmail, travelers: travelers || 1, startDate, notes
    });
    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.list = async (req, res) => {
  try {
    const rows = await Booking.find().populate('trip');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
