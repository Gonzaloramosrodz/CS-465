# Software Design Document (SDD) — Travlr Getaways (CS 465)

> NOTE: Paste this content into the official SDD template if required by your course.

## Executive Summary
This system implements Travlr Getaways as a MEAN-stack solution. The **customer-facing site** uses **Express + Handlebars (HBS)** to render trips, filters (resort, max price), trip detail, account creation, and a booking form. The **admin SPA** is built with **Angular**, providing secure login and CRUD for trips. The server exposes a **REST API** backed by **MongoDB (Mongoose)**, and **JWT** is used to protect administrative endpoints.

## System Architecture View

### Component Diagram (Description)
- **Client (Customer)**: Browser rendering HBS pages served by Express.
- **Client (Admin SPA)**: Angular app (components, services, routing).
- **Server**: Node/Express app exposing REST endpoints, Express MVC for website, JWT middleware.
- **Database**: MongoDB with collections for Users, Trips, Bookings.

Data flows from clients → REST API → Mongoose models → MongoDB and back. The Express MVC routes render server-side HBS using the same models.

### Sequence Diagram (Narrative)
- **Sign In (Admin SPA)**: Admin enters credentials → `POST /api/auth/login` → server validates → issues JWT → Angular stores token → subsequent requests include `Authorization: Bearer <token>` → server authorizes with middleware.
- **Trips (Customer)**: Browser requests `/trips?resort=&maxPrice=` → Express controller queries Mongo → renders HBS list with JSON data.
- **Admin CRUD**: Angular calls `GET /api/trips` → shows list. Create/Update/Delete calls `POST/PUT/DELETE /api/trips` with JWT → server validates → persists via Mongoose → returns updated data.
- **Booking**: Customer submits form on `/trips/:id` → `POST /bookings` → server validates trip → inserts booking → renders confirmation.

## User Interface
### Angular vs Express
- **Angular SPA** provides a dynamic admin interface with components (`LoginComponent`, `TripsComponent`), routing, and services. It consumes the REST API and attaches JWT automatically via an interceptor.
- **Express + HBS** provides server-rendered pages for public browsing and booking, following MVC (routes/controllers/views).

### SPA ↔ API Testing
- Verified with a Postman collection:
  - Unauthenticated calls to admin endpoints return 401/403.
  - After login, endpoints succeed (create/update/delete trips).
- Browser tested:
  - Filters on `/trips` work.
  - Booking form posts and renders confirmation.

## Data Model (Mongoose)
- **User**: `{ email, passwordHash, role }`
- **Trip**: `{ code, name, length, start, resort, perPerson, image, description }`
- **Booking**: `{ trip, userEmail, travelers, startDate, notes }`

## Security
- **JWT** for authentication; **middleware** enforces `authRequired` and `adminOnly`.
- Admin CRUD endpoints protected; public endpoints limited to read-only or booking create.

## Deployment / Runbook (Dev)
- Backend: `npm install && npm run seed && npm start`
- Admin SPA: `cd admin-spa && npm install && npm start`
- Optionally build Angular with `npm run build` and serve from `/admin` by copying artifacts to `travlr/admin-spa-dist`.
