const path = require('path');
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const exphbs = require('express-handlebars');

dotenv.config();
const app = express();

// Middleware
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // for form posts
app.use(cors({ origin: true, credentials: true }));

// Views (Handlebars)
app.engine('hbs', exphbs.engine({ extname: '.hbs', layoutsDir: path.join(__dirname, 'views/layouts'), partialsDir: path.join(__dirname, 'views/partials') }));
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use('/public', express.static(path.join(__dirname, 'public')));

// Database
connectDB();

// API routes
app.use('/api/auth', require('./api/routes/auth'));
app.use('/api/users', require('./api/routes/users'));
app.use('/api/trips', require('./api/routes/trips'));
app.use('/api/bookings', require('./api/routes/bookings'));

// Admin Angular SPA (served separately via ng serve on port 4200 typically)
// For convenience, also serve built artifacts if user runs `ng build --output-path dist`:
app.use('/admin', express.static(path.join(__dirname, 'admin-spa-dist')));

// Website (customer-facing) routes
app.use('/', require('./website/routes'));

// Health
app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
