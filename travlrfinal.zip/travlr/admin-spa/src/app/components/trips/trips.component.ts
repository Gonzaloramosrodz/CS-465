import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-trips',
  templateUrl: './trips.component.html'
})
export class TripsComponent implements OnInit {
  trips:any[] = [];
  editing:any = null;
  form:any = {};
  constructor(private api: ApiService){}
  ngOnInit(){ this.refresh(); }
  async refresh(){ this.trips = await this.api.tripsList().toPromise(); }
  new(){ this.editing = null; this.form = {}; }
  edit(t:any){ this.editing = t; this.form = { ...t }; }
  async save(){
    if(this.editing){ await this.api.tripUpdate(this.editing._id, this.form).toPromise(); }
    else { await this.api.tripCreate(this.form).toPromise(); }
    this.editing = null; this.form = {}; this.refresh();
  }
  async del(t:any){ await this.api.tripDelete(t._id).toPromise(); this.refresh(); }
}
