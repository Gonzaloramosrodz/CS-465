import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  email = 'admin@example.com';
  password = 'Admin123!';
  error = '';
  loading = false;
  constructor(private auth: AuthService) {}
  async submit(){
    this.error = ''; this.loading = true;
    try { await this.auth.login(this.email, this.password); }
    catch { this.error = 'Invalid login'; }
    finally { this.loading = false; }
  }
}
