import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ApiService {
  base = 'http://localhost:3000/api';
  constructor(private http: HttpClient) {}
  login(email:string, password:string){ return this.http.post<any>(`${this.base}/auth/login`, { email, password }); }
  me(){ return this.http.get<any>(`${this.base}/auth/me`); }
  tripsList(){ return this.http.get<any[]>(`${this.base}/trips`); }
  tripGet(id:string){ return this.http.get<any>(`${this.base}/trips/${id}`); }
  tripCreate(payload:any){ return this.http.post<any>(`${this.base}/trips`, payload); }
  tripUpdate(id:string, payload:any){ return this.http.put<any>(`${this.base}/trips/${id}`, payload); }
  tripDelete(id:string){ return this.http.delete<any>(`${this.base}/trips/${id}`); }
}
