import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { ApiService } from './api.service';

@Injectable()
export class AuthService {
  token: string | null = localStorage.getItem('token');
  user: any = null;
  constructor(private api: ApiService, private router: Router) {}
  async login(email:string, password:string){
    const res = await this.api.login(email, password).toPromise();
    this.token = res.token;
    localStorage.setItem('token', this.token!);
    this.user = res.user;
    await this.router.navigateByUrl('/trips');
  }
  logout(){
    this.token = null;
    this.user = null;
    localStorage.removeItem('token');
    this.router.navigateByUrl('/login');
  }
}

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = localStorage.getItem('token');
    if (token) {
      const authReq = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
      return next.handle(authReq);
    }
    return next.handle(req);
  }
}
