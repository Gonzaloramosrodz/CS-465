const express = require("express");
const router = express.Router();

// View controller (renders the trips page)
const tripsView = require("../controllers/tripsView");

// API controller (returns trip data from MongoDB as JSON)
const tripsApi = require("../controllers/trips");

// HTML page route
router.get("/", tripsView.listTrips);

// API route (for Module 4 assignment)
router.get("/api", tripsApi.tripsList);

module.exports = router;
