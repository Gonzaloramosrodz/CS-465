const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");

// Connect to MongoDB
mongoose.connect("mongodb://localhost/travlr", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Load the model
require("./app_server/models/trips");
const Trip = mongoose.model("Trip");

// Load JSON data
const dataPath = path.join(__dirname, "trips.json");
const tripsData = JSON.parse(fs.readFileSync(dataPath, "utf8"));

// Remove existing and insert new
Trip.deleteMany({})
  .then(() => Trip.insertMany(tripsData))
  .then(() => {
    console.log("Database seeded successfully.");
    mongoose.connection.close();
  })
  .catch((err) => {
    console.error("Seeding error:", err);
    mongoose.connection.close();
  });
