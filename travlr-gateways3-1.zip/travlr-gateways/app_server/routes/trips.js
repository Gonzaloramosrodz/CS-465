const express = require("express");
const router = express.Router();
const controller = require("../controllers/trips");

// Route for /trips
router.get("/", controller.listTrips);

module.exports = router;
