const express = require("express");
const router = express.Router();
const controller = require("../controllers/travel");

// This will respond to http://localhost:3000/travel
router.get("/", controller.travelInfo);

module.exports = router;
