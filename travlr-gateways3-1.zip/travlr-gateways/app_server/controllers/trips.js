const trips = require("../../data/trips.json");

module.exports.listTrips = (req, res) => {
  console.log("Rendering /trips page:", trips.length, "trips loaded");
  res.render("trips", {
    title: "Our Trips",
    trips: trips,
  });
};
