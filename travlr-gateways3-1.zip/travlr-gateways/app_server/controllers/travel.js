module.exports.travelInfo = function (req, res) {
  res.render("travel", {
    title: "Travel Page",
    trips: [
      { location: "Cancun", price: "$899", dates: "July 15–21" },
      { location: "Barcelona", price: "$1199", dates: "August 10–18" },
      { location: "Tokyo", price: "$1399", dates: "September 1–9" },
    ],
  });
};
